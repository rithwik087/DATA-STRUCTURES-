/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<ctype.h>
#include<string.h>
#define S 20

struct stack
{
   char e[S];
   int top;
}st;

void push(char a)
{
	if(st.top<S)
   {
   	 st.e[st.top] = a;
    	st.top++;
   }
   else
   	printf("\nStack overflow.");
}

char pop()
{
	if(st.top>-1)
    {
   		st.top--;
   		return st.e[st.top];
    }
   else
   	printf("\nStack Empty");
   return '\0';
}


int Priority(char w)
{
   if(w == '^')
	return 3;
   else if(w=='*'||w=='/')
   	return 2;
   else if(w=='+'||w=='-')
   	return 1;
   else if(w=='(')
   	return -1;
   return 0;
}


void Convert(char infix[S],char post[S])
{
	int i=0,j=0;
   for(i=0;infix[i]!='\0';i++)
   {
   	if(infix[i]=='(')
      	push(infix[i]);

    else if(isalpha(infix[i]))
      	post[j++] = infix[i];

    else if(Priority(infix[i])>0)
      {
      	char c=pop();
         while(Priority(c)>0&&(Priority(c)>Priority(infix[i])))
         {
         	post[j++] = c;
            c=pop();
         }
         push(c);
         push(infix[i]);
      }

      else if(infix[i]==')')
      {
      	char c=pop();
         while(c!='(')
         {
         	post[j++] = c;
				c = pop();
         }
      }
   }
   post[j]='\0';
}



int main()
{
	st.top = 0;
	char inf[S],pof[S];
	printf("Enter an infix expression : \n");
	scanf("%s",&inf);
	strcat(strrev(inf),"("); 
    strcat(strrev(inf),")");    
	
	Convert(inf,pof);
	printf("\n Postfix : %s",pof);
}
