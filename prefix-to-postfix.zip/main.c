/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define SIZE 50

// initialising stack
struct stack
{
    char stack1[SIZE];
    int top;
};

void initializeStack(struct stack *s)
{
    s->top = -1;
}


int isStackEmpty(struct stack *s)
{
    if(s->top == -1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}


int isStackFull(struct stack *s)
{
    if(s->top == SIZE - 1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}


void push(struct stack *s, char c)
{
    if(!isStackFull(s))
    {
        s->stack1[s->top+1] = c;
        s->top+=1;
    }
    else
    {
        printf("Stack Full");
    }
}


char pop(struct stack *s)
{
    if(!isStackEmpty(s))
    {
        char returnValue = s->stack1[s->top];
        s->top-=1;
        return returnValue;
    }
    else
    {
        printf("Stack Empty");
    }
}


struct queue
{
    char queue1[SIZE];
    int front;
    int rear;
    int count;
};

void initializeQueue(struct queue* q)
{
    q->front = 0;
    q->rear = -1;
    q->count = 0;
}


int isQueueEmpty(struct queue* q)
{
    return q->count == 0;
}


int isQueueFull(struct queue* q)
{
    return q->count>=SIZE;
}


void enqueue(struct queue* q, char x)
{
    if(!isQueueFull(q))
    {
        q->count++;
        q->rear+=1;
        q->queue1[q->rear] = x;
    }
    else
    {
        printf("Queue Full");
    }
}


char dequeue(struct queue* q)
{
    if(!isQueueEmpty(q))
    {
        q->count--;
        char retVal = q->queue1[q->front];
        q->front+=1;
        return retVal;
    }
    else
    {
        printf("Queue empty");
    }
}

 
int main()
{
    struct stack OP;
    struct queue QUEUEIN, QUEUEOUT;

    initializeStack(&OP);
    initializeQueue(&QUEUEIN);
    initializeQueue(&QUEUEOUT);

    printf("Enter the prefix expression:\n");
    char prefix[SIZE];
    gets(prefix);
    int i,check = 0;

    //Incorrect input check(alternate op check)
    
    if(prefix[0]!='+' && prefix[0]!='-' && prefix[0]!='*' && prefix[0]!='/')
    {
     check=1;
    }
    else
    {
        for(i=0;prefix[i]!='\0';i++)
        {
            if(prefix[i]=='+' || prefix[i]=='-' || prefix[i]=='*' || prefix[i]=='/')
            {
                if(prefix[i+1]=='+' || prefix[i+1]=='-' || prefix[i+1]=='*' || prefix[i+1]=='/')
                {
                    continue;
                }
                else
                {
                    if(prefix[i+2]=='+' || prefix[i+2]=='-' || prefix[i+2]=='*' || prefix[i+2]=='/')
                    {
                        check = 1;
                        break;
                    }
                }
            }  
        }
    }

    // correct
    
    if(check==0){
        for(i=0;prefix[i]!='\0';i++)
        {
            enqueue(&QUEUEIN,prefix[i]);
        }
        int flag = 0;
        while(!isQueueEmpty(&QUEUEIN))
        {   
            char item = dequeue(&QUEUEIN);
            if(item!='+' && item!='-' && item!='*' && item!='/')
            {
                enqueue(&QUEUEOUT,item);
                flag = 1;
            }
            else
            {
                if(flag==0)
				{
                    push(&OP,item);
                }
                else
                {
                    enqueue(&QUEUEOUT,pop(&OP));
                    push(&OP,item);
                    flag = 0;
                }
            }
        }
        while(!isStackEmpty(&OP))
        {
            enqueue(&QUEUEOUT,pop(&OP));
        }

        printf("Result: ");
        for(i=0;!isQueueEmpty(&QUEUEOUT);i++)
        {
            printf("%c",dequeue(&QUEUEOUT));
        }
    }

    else
    {
        printf("Prefix expression is incorrect");
    }
    return 0;
}
