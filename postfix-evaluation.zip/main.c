/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <conio.h>
#include <stdio.h>
#define SIZE 20



struct stack
{
	int e[SIZE];
   int top;
};



void getinput(char in[])
{
 	printf("Enter the postfixed expression :\n");
   scanf("%s",in);
}



int evaluate(char exp[])
{
   struct stack sx;
   sx.top=0;
	int i=0;
   for(;exp[i]!='\0';i++)
   {
   	if((exp[i]>='0')&&(exp[i]<='9'))
      	sx.e[sx.top++]=(exp[i]-48);


      else if(exp[i]=='+')
      {
      	sx.e[sx.top-2] = sx.e[sx.top-2] + sx.e[sx.top-1];
         sx.top--;
      }

      else if(exp[i]=='-')
      {
      	sx.e[sx.top-2] = sx.e[sx.top-2] - sx.e[sx.top-1];
         sx.top--;
      }

      else if(exp[i]=='*')
      {
      	sx.e[sx.top-2] = sx.e[sx.top-2] * sx.e[sx.top-1];
         sx.top--;
      }

      else if(exp[i]=='/')
      {
      	sx.e[sx.top-2] = sx.e[sx.top-2] / sx.e[sx.top-1];
         sx.top--;
      }

      else if(sx.top<0)
      	printf("Stack undeflow, error.");

      else
      	printf("Invalid operand, error.");

   }

   return sx.e[sx.top-1];
}



int main()
{
	char postfix[SIZE];
   getinput(postfix);

   printf("\n The result is %d.",evaluate(postfix));

	getch();
   return 0;
}