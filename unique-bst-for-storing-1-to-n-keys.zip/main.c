/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/* Number of unqiue BST (structure-wise) for storing 1 to N */
#include <stdio.h>

int unq(int n)
{
	int sum = 0;
	int i;
	if(n == 0)
	{
		return 1;
	}
	else
	{
		for(i = 0; i <= n-1; i++)
		{
			sum = sum + unq(i)*unq(n-1-i);
		}
		return sum;
	}
}

int main()
{
	printf("%d", unq(4));
}

